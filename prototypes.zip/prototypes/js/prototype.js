(function($) {
    'use strict';

    $(function() {

        $(document).ready(function() {
            //preloader
            $(window).on('load', function() {
                setTimeout(() => {
                    const $loader = $("#loader");
                    $loader.addClass('preload-finish');
                }, 2000);

            });
            //hamburger toggle
            $('.hamburger').click(function() {
                $(this).toggleClass('is-active');
                $('#overlay').toggleClass('is-open');
            });

            // sticky header

            var header = $('.header').outerHeight(),
                headerOffset = $('.header').offset().top;
            $(window).scroll(function() {
                var scrollPos = $(window).scrollTop() - header;
                if (scrollPos >= header) {
                    $(".header").addClass('is-sticky');
                } else {
                    $('.header').removeClass('is-sticky');
                }

            });

            //animated scroll link with active class
            var scrollLink = $('.scroll');
            scrollLink.click(function() {
                $('body html').animate({
                    scrollTop: $(this.hash).offset().top
                });
            });

            $(window).scroll(function() {
                var scrollPos = $(window).scrollTop();

                scrollLink.each(function(e) {
                    e.preventDefault;
                    var scrollOffset = $(this.hash).offset().top;
                    if (scrollOffset <= scrollPos) {
                        $(this).parent().addClass('active');
                        $(this).parent().siblings().removeClass('active');
                    }
                })
            })
            // owl carousel
            var $carouselObject = $('.hero-slideshow');
            $carouselObject.owlCarousel({
                items: 1,
                loop: true,
                margin: 10,
                nav: false,
                navText: ["<i class='fa fa-angle-left' aria-hidden='true'></i>", "<i class='fa fa-angle-right' aria-hidden='true'></i>"],
                autoplay: true,
                dots: false,
                animateIn: 'fadeIn',
                animateOut: 'fadeOut',
                mouseDrag: false,
                touchDrag: false,
                pullDrag: false,
                freeDrag: false,
                lazyLoad: false
            });
            // swiper slider
            var mySwiper = new Swiper('.swiper-container', {
                // Optional parameters
                direction: 'vertical',
                loop: true,

                // If we need pagination
                pagination: {
                    el: '.swiper-pagination',
                },

                // Navigation arrows
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                }
            })

        });

    });

})(jQuery);



// $(".accordion").on("click", ".accordion-header", function() {
//     $(this).toggleClass("active").next().slideToggle();
//  });


// $(".tab-list").on("click", ".tab", function(e) {
//     e.preventDefault();

//     $(".tab").removeClass("active");
//     $(".tab-content").removeClass("show");
//     $(this).addClass("active");
//     $($(this).attr("href")).addClass("show");
// });


// <div class="tabs">
// <nav class="tab-list">
// <a class="tab" href="#one">One</a>
// <a class="tab" href="#two">Two</a>
// <a class="tab active" href="#three">Three</a>
// </nav>
// <div id="one" class="tab-content">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. </div>
// <div id="two" class="tab-content">Et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</div>
// <div id="three" class="tab-content show">Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur.</div>
// </div>

// .tab {
//     border: 1px solid transparent;
//     border-radius: 40px;
//     display: inline-block;
//     text-decoration: none;
//     padding: .5rem 1rem;
//     color: rgba(255, 255, 255, .6);
//     font-weight: 700;
//     background: rgba(10, 20, 30, .2);
// }
// .tab-content {
//     background: linear-gradient(to bottom right, white, #F8F8F8);
//     box-shadow: 0 15px 20px -15px rgba(0, 0, 0, 0.3), 0 35px 50px -25px rgba(0, 0, 0, 0.3), 0 85px 60px -25px rgba(0, 0, 0, 0.1);
//     display: none;
//     padding: 1.5rem;
//     color: #4a5666;
// }
// .show {
//     display: block;
// }

// Clicking away from the dropdown will collapse it.
// $('html').click(function() {
//   $('.dropdown').hide()
// })

// // Any nav item that is not an only child...
// $('nav ul li a:not(:only-child)').click(function(e) {
//   // will be toggled.
//   $(this)
//     .siblings('.dropdown')
//     .toggle()

//   // Opening a new dropdown will collapse any other dropdown.
//   $('.dropdown')
//     .not($(this).siblings())
//     .hide()

//   e.stopPropagation()
// })