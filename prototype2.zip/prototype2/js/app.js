(function($) {
    'use strict';

    $(function() {

        $(document).ready(function() {
            // Stikcy header

            // toggle menu
            const hamburger = $('.hamburger');
            hamburger.click(function() {
                $(this).toggleClass('is-active');
            });

            // swiper slider
            if ($(".hero-slider .swiper-slide").length) {
                var swiper11 = new Swiper('.hero-slider .swiper-container', {
                    direction: 'horizontal',
                    centeredSlides: true,
                    speed: 2000,
                    autoplay: true,
                    spaceBetween: 0,
                    loop: true,
                    grabCursor: false,
                    slidesPerView: 1,
                    autoHeight: false,
                    simulateTouch: false
                });
            }
            if (!Modernizr.objectfit) {
                $('.swiper-container').each(function() {
                    var $container = $(this),
                        imgURL = $container.find('img').prop('src');

                    if (imgURL) {
                        $container
                            .css('background-image', 'url(' + imgURL + ')')
                            .addClass('compact-object-fit');
                    }
                })
            }
            // for svg
            if (!Modernizr.svg) {
                var imgAttr = $('img[src$=".svg"]');
                // console.log(imgAttr);

                imgAttr.each(function() {
                    //Replaces '*.svg' with '*.png'.
                    $(this).attr('src', $(this).attr('src').replace('.svg', '.png'));
                });
            }
            // owl carousel
            // scroll Link

            // add link active on scroll

            //full height
            resizeElement();
        });

        window.onresize = function(event) {
            resizeElement();
        }

        function resizeElement() {
            var vpw = $(window).width(); //view port width
            var vph = $(window).height(); //view port height

            //$('#main').css({'height': vph});
        }

        // other method

        $(window).resize(function() {
            //$('.slider-wrapper').css('height', window.innerHeight);
        });

        // modernizr 


    });


})(jQuery);